// Guitarra.java
public class Guitarra {
    // Atributos
    private String marca;
    private String tipo;
    private int numeroCuerdas;
    private double precio;

    // Constructor
    public Guitarra(String marca, String tipo, int numeroCuerdas, double precio) {
        this.marca = marca;
        this.tipo = tipo;
        this.numeroCuerdas = numeroCuerdas;
        this.precio = precio;
    }

    // Getters & Setters
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getNumeroCuerdas() {
        return numeroCuerdas;
    }

    public void setNumeroCuerdas(int numeroCuerdas) {
        this.numeroCuerdas = numeroCuerdas;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    // Métodos adicionales
    public void afinar() {
        System.out.println("La guitarra está afinada.");
    }

    public void tocar() {
        System.out.println("Tocando la guitarra...");
    }

    public void cambiarCuerdas() {
        System.out.println("Cambiando las cuerdas de la guitarra.");
    }
}