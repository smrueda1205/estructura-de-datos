 // Planeta.java
public class Planeta {
    // Atributos
    private String nombre;
    private double masa;
    private double diametro;
    private double gravedad;

    // Constructor
    public Planeta(String nombre, double masa, double diametro, double gravedad) {
        this.nombre = nombre;
        this.masa = masa;
        this.diametro = diametro;
        this.gravedad = gravedad;
    }

    // Getters & Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getMasa() {
        return masa;
    }

    public void setMasa(double masa) {
        this.masa = masa;
    }

    public double getDiametro() {
        return diametro;
    }

    public void setDiametro(double diametro) {
        this.diametro = diametro;
    }

    public double getGravedad() {
        return gravedad;
    }

    public void setGravedad(double gravedad) {
        this.gravedad = gravedad;
    }

    // Métodos adicionales
    public void rotar() {
        System.out.println("El planeta está rotando.");
    }

    public void orbitar() {
        System.out.println("El planeta está orbitando alrededor de su estrella.");
    }

    public void calcularDensidad() {
        double densidad = masa / (Math.PI * Math.pow((diametro / 2), 3) / 6);
        System.out.println("La densidad del planeta es: " + densidad + " kg/m^3");
    }
}
