// Main.java
public class Main {
    public static void main(String[] args) {
        // Crear objetos de las clases Guitarra y Planeta
        Guitarra miGuitarra = new Guitarra("Fender", "Eléctrica", 6, 500.0);
        Planeta tierra = new Planeta("Tierra", 5.972e24, 12742, 9.8);

        // Imprimir un atributo de cada objeto
        System.out.println("Marca de la guitarra: " + miGuitarra.getMarca());
        System.out.println("Nombre del planeta: " + tierra.getNombre());
    }
}